package com.example.compras;

import java.io.Serializable;

// La clase implementa Serializable para poder pasarla entre Activities con Intent.putExtra()
// Esto es necesario para enviar objetos Producto a SecondActivity a través del Intent
public class Producto implements Serializable {

    private int id;
    private String titulo;
    private double precio;
    private String imagenUrl; // URL de la imagen del producto (se cargará con Glide)

    // Constructor con todos los campos
    public Producto(int id, String titulo, double precio, String imagenUrl) {
        this.id = id;
        this.titulo = titulo;
        this.precio = precio;
        this.imagenUrl = imagenUrl;
    }

    // Getters para acceder a los campos desde otras clases
    public int getId() { return id; }
    public String getTitulo() { return titulo; }
    public double getPrecio() { return precio; }
    public String getImagenUrl() { return imagenUrl; }
}
