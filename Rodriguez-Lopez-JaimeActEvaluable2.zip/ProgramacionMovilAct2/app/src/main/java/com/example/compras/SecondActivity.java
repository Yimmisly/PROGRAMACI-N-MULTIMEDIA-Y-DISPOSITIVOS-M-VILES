package com.example.compras;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.snackbar.Snackbar;

import java.util.ArrayList;
import java.util.List;

public class SecondActivity extends AppCompatActivity {

    // Lista local de productos que están en el carrito
    private List<Producto> carritoLocal = new ArrayList<>();

    // Adapter del RecyclerView del carrito
    private CarritoAdapter carritoAdapter;

    // TextView donde se mostrará el precio total
    private TextView tvTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        // Recuperamos el carrito que fue enviado desde MainActivity con putExtra
        // Lo casteamos a ArrayList<Producto> (que es Serializable)
        ArrayList<Producto> carritoRecibido = (ArrayList<Producto>) getIntent()
                .getSerializableExtra("carrito");

        // Si el carrito no es null, lo copiamos en nuestra lista local
        if (carritoRecibido != null) {
            carritoLocal.addAll(carritoRecibido);
        }

        // Referencia al RecyclerView del carrito
        RecyclerView recyclerView = findViewById(R.id.recyclerViewCarrito);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Creamos el adapter con la lista del carrito
        carritoAdapter = new CarritoAdapter(carritoLocal);
        recyclerView.setAdapter(carritoAdapter);

        // Referencia al TextView del total
        tvTotal = findViewById(R.id.tvTotal);

        // Calculamos y mostramos el precio total al abrir la pantalla
        actualizarTotal();
    }

    // Infla el menú superior específico de esta Activity (menu_second.xml)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_second, menu);
        return true;
    }

    // Gestiona las pulsaciones de los items del menú de SecondActivity
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_confirmar_compra) {
            // Calculamos el total para mostrarlo en el Snackbar de confirmación
            double total = calcularTotal();
            String mensaje = String.format("Enhorabuena, compra por valor de %.2f € realizada", total);

            // Snackbar: mensaje breve en la parte inferior de la pantalla
            Snackbar.make(findViewById(android.R.id.content), mensaje, Snackbar.LENGTH_LONG).show();
            return true;

        } else if (id == R.id.action_vaciar_carrito) {
            // Vaciamos la lista local del carrito
            carritoLocal.clear();

            // Notificamos al adapter para que actualice el RecyclerView (borra todas las filas)
            carritoAdapter.notifyDataSetChanged();

            // Actualizamos el total (quedará en 0.00 €)
            actualizarTotal();

            // Mostramos el Snackbar de confirmación
            Snackbar.make(findViewById(android.R.id.content), "Carrito vaciado", Snackbar.LENGTH_SHORT).show();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    // Calcula la suma de los precios de todos los productos del carrito
    private double calcularTotal() {
        double total = 0;
        for (Producto p : carritoLocal) {
            total += p.getPrecio();
        }
        return total;
    }

    // Actualiza el TextView del total con el precio calculado
    private void actualizarTotal() {
        tvTotal.setText(String.format("Total: %.2f €", calcularTotal()));
    }
}
