package com.example.compras;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ProductoAdapter.OnAddToCartListener {

    // Lista que almacena todos los productos cargados desde la API
    private List<Producto> listaProductos = new ArrayList<>();

    // Lista que almacena los productos que el usuario ha añadido al carrito
    private List<Producto> carrito = new ArrayList<>();

    // Adapter para conectar la lista de productos con el RecyclerView
    private ProductoAdapter adapter;

    // Spinner donde se mostrarán las categorías
    private Spinner spinnerCategorias;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Referencia al RecyclerView definido en el layout XML
        RecyclerView recyclerView = findViewById(R.id.recyclerViewProductos);

        // Usamos LinearLayoutManager para mostrar los items en forma de lista vertical
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Creamos el adapter pasándole la lista de productos y el listener del botón "Añadir"
        adapter = new ProductoAdapter(listaProductos, this);
        recyclerView.setAdapter(adapter);

        // Referencia al Spinner de categorías
        spinnerCategorias = findViewById(R.id.spinnerCategorias);

        // Llamamos al método para cargar las categorías desde la API
        cargarCategorias();

        // Llamamos al método para cargar los productos desde la API
        cargarProductos();
    }

    // Infla (muestra) el menú superior definido en res/menu/menu_main.xml
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // Controla las pulsaciones en los items del menú superior
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.action_ver_carrito) {
            // Al pulsar "Ver carrito", abrimos SecondActivity
            // Pasamos el carrito como ArrayList Serializable con putExtra
            Intent intent = new Intent(this, SecondActivity.class);
            intent.putExtra("carrito", (ArrayList<Producto>) carrito);
            startActivity(intent);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    // Método que realiza la petición a la API para obtener las categorías
    private void cargarCategorias() {
        // Creamos la cola de peticiones de Volley (singleton de red)
        RequestQueue queue = Volley.newRequestQueue(this);

        // URL de la API que devuelve las categorías en formato JSON
        String url = "https://dummyjson.com/products/categories";

        // StringRequest: petición que devuelve la respuesta como String
        StringRequest request = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        // Parseamos la respuesta como JSONArray (lista de strings)
                        JSONArray jsonArray = new JSONArray(response);
                        List<String> categorias = new ArrayList<>();
                        categorias.add("Todas las categorías"); // Opción por defecto

                        // Recorremos el array para extraer cada categoría
                        for (int i = 0; i < jsonArray.length(); i++) {
                            // Puede ser un String o un objeto con "name"
                            Object item = jsonArray.get(i);
                            if (item instanceof JSONObject) {
                                categorias.add(((JSONObject) item).optString("name", item.toString()));
                            } else {
                                categorias.add(item.toString());
                            }
                        }

                        // Vinculamos la lista de categorías al Spinner mediante un ArrayAdapter
                        ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<>(
                                this,
                                android.R.layout.simple_spinner_item,
                                categorias
                        );
                        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                        spinnerCategorias.setAdapter(spinnerAdapter);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error al cargar categorías", Toast.LENGTH_SHORT).show()
        );

        // Añadimos la petición a la cola para ejecutarla
        queue.add(request);
    }

    // Método que realiza la petición a la API para obtener la lista de productos
    private void cargarProductos() {
        RequestQueue queue = Volley.newRequestQueue(this);
        String url = "https://dummyjson.com/products";

        // JsonObjectRequest: petición que parsea directamente la respuesta como JSONObject
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        // La API devuelve un objeto con una clave "products" que contiene el array
                        JSONArray products = response.getJSONArray("products");

                        // Recorremos cada producto del array
                        for (int i = 0; i < products.length(); i++) {
                            JSONObject p = products.getJSONObject(i);

                            // Extraemos los campos que necesitamos de cada producto
                            int id = p.getInt("id");
                            String titulo = p.getString("title");
                            double precio = p.getDouble("price");

                            // La imagen está en el array "images" (primera imagen) o en "thumbnail"
                            String imagen = p.optString("thumbnail", "");

                            // Creamos el objeto Producto y lo añadimos a la lista
                            listaProductos.add(new Producto(id, titulo, precio, imagen));
                        }

                        // Notificamos al adapter que los datos han cambiado para que redibuje la lista
                        adapter.notifyDataSetChanged();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Error al cargar productos", Toast.LENGTH_SHORT).show()
        );

        queue.add(request);
    }

    // Callback del interface OnAddToCartListener definido en el adapter
    // Se llama automáticamente cuando el usuario pulsa el botón "Añadir" en un producto
    @Override
    public void onAddToCart(Producto producto) {
        carrito.add(producto);
        Toast.makeText(this, producto.getTitulo() + " añadido al carrito", Toast.LENGTH_SHORT).show();
    }
}
