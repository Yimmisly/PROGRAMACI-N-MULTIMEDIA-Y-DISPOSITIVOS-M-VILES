package com.example.compras;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

// Adapter para mostrar los productos del carrito en SecondActivity
// Más sencillo que ProductoAdapter: solo muestra imagen, nombre y precio (sin botón)
public class CarritoAdapter extends RecyclerView.Adapter<CarritoAdapter.CarritoViewHolder> {

    private List<Producto> carritoProductos;

    public CarritoAdapter(List<Producto> carritoProductos) {
        this.carritoProductos = carritoProductos;
    }

    @NonNull
    @Override
    public CarritoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos el layout de cada fila del carrito
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_carrito, parent, false);
        return new CarritoViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CarritoViewHolder holder, int position) {
        Producto producto = carritoProductos.get(position);

        holder.tvNombre.setText(producto.getTitulo());
        holder.tvPrecio.setText(String.format("%.2f €", producto.getPrecio()));

        // Cargamos la imagen con Glide igual que en el adapter de productos
        Glide.with(holder.itemView.getContext())
                .load(producto.getImagenUrl())
                .placeholder(android.R.drawable.ic_menu_gallery)
                .into(holder.ivProducto);
    }

    @Override
    public int getItemCount() {
        return carritoProductos.size();
    }

    // ViewHolder para las filas del carrito
    public static class CarritoViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProducto;
        TextView tvNombre;
        TextView tvPrecio;

        public CarritoViewHolder(@NonNull View itemView) {
            super(itemView);
            ivProducto = itemView.findViewById(R.id.ivCarritoProducto);
            tvNombre = itemView.findViewById(R.id.tvCarritoNombre);
            tvPrecio = itemView.findViewById(R.id.tvCarritoPrecio);
        }
    }
}
