package com.example.compras;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.List;

// Adapter que conecta la lista de Productos con el RecyclerView
// Extiende RecyclerView.Adapter con su propio ViewHolder
public class ProductoAdapter extends RecyclerView.Adapter<ProductoAdapter.ProductoViewHolder> {

    private List<Producto> listaProductos;

    // Interface de Callback: permite que la Activity sepa cuándo se pulsa "Añadir al carrito"
    // sin que el Adapter necesite tener referencia directa a la Activity
    public interface OnAddToCartListener {
        void onAddToCart(Producto producto);
    }

    private OnAddToCartListener listener;

    // Constructor: recibe la lista de datos y el listener del callback
    public ProductoAdapter(List<Producto> listaProductos, OnAddToCartListener listener) {
        this.listaProductos = listaProductos;
        this.listener = listener;
    }

    // Se llama cuando el RecyclerView necesita crear un nuevo ViewHolder (nueva fila visible)
    @NonNull
    @Override
    public ProductoViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflamos el layout XML de cada fila (item_producto.xml)
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_producto, parent, false);
        return new ProductoViewHolder(view);
    }

    // Se llama para rellenar los datos de un ViewHolder con el producto en la posición indicada
    @Override
    public void onBindViewHolder(@NonNull ProductoViewHolder holder, int position) {
        Producto producto = listaProductos.get(position);

        // Asignamos el nombre y precio del producto a los TextViews correspondientes
        holder.tvNombre.setText(producto.getTitulo());
        holder.tvPrecio.setText(String.format("%.2f €", producto.getPrecio()));

        // Usamos Glide para cargar la imagen de forma asíncrona desde la URL
        // Glide gestiona la caché, el hilo de fondo y el placeholder automáticamente
        Glide.with(holder.itemView.getContext())
                .load(producto.getImagenUrl())
                .placeholder(android.R.drawable.ic_menu_gallery) // Imagen mientras carga
                .into(holder.ivProducto);

        // Al pulsar el botón "Añadir al carrito", llamamos al callback con el producto
        holder.btnAnadir.setOnClickListener(v -> listener.onAddToCart(producto));
    }

    // Devuelve el número total de elementos de la lista
    @Override
    public int getItemCount() {
        return listaProductos.size();
    }

    // ViewHolder: contiene referencias a las vistas de cada fila para no tener que buscarlas cada vez
    // Esto mejora el rendimiento del RecyclerView al hacer scroll
    public static class ProductoViewHolder extends RecyclerView.ViewHolder {
        ImageView ivProducto;
        TextView tvNombre;
        TextView tvPrecio;
        Button btnAnadir;

        public ProductoViewHolder(@NonNull View itemView) {
            super(itemView);
            // Enlazamos cada variable con su vista del layout mediante el ID
            ivProducto = itemView.findViewById(R.id.ivProducto);
            tvNombre = itemView.findViewById(R.id.tvNombreProducto);
            tvPrecio = itemView.findViewById(R.id.tvPrecioProducto);
            btnAnadir = itemView.findViewById(R.id.btnAnadir);
        }
    }
}
